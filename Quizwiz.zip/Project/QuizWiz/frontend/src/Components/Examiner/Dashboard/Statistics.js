import React from "react";
import PreviousQuiz from "./StatsComponent/PreviousQuiz";
function Statistics() {
  return (
    <div>
      <div>
        <PreviousQuiz></PreviousQuiz>
      </div>
    </div>
  );
}

export default Statistics;
