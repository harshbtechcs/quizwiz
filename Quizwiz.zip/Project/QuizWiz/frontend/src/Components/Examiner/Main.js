import React from "react";

function Examiner() {
  return <div>Examiner</div>;
}

export default Examiner;
