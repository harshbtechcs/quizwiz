import React from 'react'

export default function AboutUs() {
  return (
    <div>AboutUs</div>
  )
}
