export const sampleUsers = {
  quizzesAttended: [
    { code: 101, score: 85, totalMarks: 100, date: "2024-01-15", topic: "Data Structures", examiner: "Mr Prashant Pathak"},
    { code: 102, score: 92, totalMarks: 100, date: "2024-02-20", topic: "Algorithms" , examiner: "Mr Prashant Pathak"},
    { code: 103, score: 78, totalMarks: 100, date: "2024-03-05", topic: "Database Systems" , examiner: "Mr Prashant Pathak"},
    { code: 104, score: 20, totalMarks: 100, date: "2024-04-10", topic: "Operating Systems" , examiner: "Mr Prashant Pathak"},
  ],
  numberQuizAttended:50
};

export default sampleUsers;
